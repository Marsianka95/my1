#include<iostream>
#include<string>
using namespace std;
class Auto
{
public:
	int year;
	int mileage;
	int price;
	string color;
	string brand;

	void print()
	{
		cout << "�������������  " << brand <<"\n��� �������  " << year <<"\n������  " << mileage << "\n����  " << price << "\n����  " << color <<endl;
	}
};

	int main() {
		setlocale(LC_ALL, "ru");
		Auto a;
		a.brand = "Audi";
		a.year = 1995;
		a.mileage = 1000;
		a.price = 20000;
		a.color = "red";
		a.print();
		cout << "_____________________" << endl;

		Auto b;
		b.brand = "Nissan";
		b.year = 2000;
		b.mileage = 0;
		b.price = 50000;
		b.color = "black";
		b.print();
		cout << "_______________________" << endl;


		Auto c;
		c.brand = "Zhiguli";
		c.year = 1986;
		c.mileage = 40000;
		c.price = 500;
		c.color = "green";
		c.print();
		system("pause");


	}
